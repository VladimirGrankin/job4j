/**
* Package for calculate task - lesson 1.1 HelloWorld.
*
* @author Vladimir Grankin (mailto:)
* @version 0.1
* @since 0.1
*/
package ru.job4j.calculate;